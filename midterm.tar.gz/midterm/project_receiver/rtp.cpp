/*
 * rtp.cpp
 *
 *  Created on: 2015. 5. 1.
 *      Author: nini
 */
#include "rtp.h"

static unsigned timestamp;
//  send RTP packets
void rtp_send_packets(int sock, struct sockaddr_in* to, char *rtp_data, unsigned long length, unsigned payload_size){

	rtp_hdr* rtphdr; //address of rtphdr
    char*           rtp_payload; //where can i have to payload (pointer)
    u_int32         rtp_payload_size, rtp_data_index; //u_int32 : int
    u_int8 *rtp_send_packet = (u_int8 *) malloc(payload_size); //u_int8 : char

    // prepare RTP packet
    rtphdr = (rtp_hdr*) rtp_send_packet;
    rtphdr->flags = RTP_VERSION; //save RTP_VERSION in 'flag'
    rtphdr->mk_pt = RTP_PAYLOADTYPE; //save RTP_PAYLOADTYPE in 'mk_pt'
    rtphdr->ssrc  = htonl(RTP_SSRC);
    timestamp += 1000/30;
    rtphdr->timestamp   = htonl(ntohl(timestamp));

    // send RTP stream packets
    rtp_data_index = 0;
    do {
    	 memset(rtp_send_packet, 0, sizeof(rtp_send_packet)); //fill '0' in all of them
    	 //memset : receive point/what are you fill in address/how many bytes will you allocate

        rtp_payload      = rtp_send_packet + sizeof(rtp_hdr);
        rtp_payload_size = MIN(payload_size , (length - rtp_data_index)); //minimum thing in one of two

        memcpy(rtp_payload, rtp_data + rtp_data_index, rtp_payload_size); //copy in rtp_payload
         //memcpy : copy one part of memory, address of copyied data/address of datas to copy/bytes of data to copy

        // set MARKER bit in RTP header on the last packet of an image
        rtphdr->mk_pt = RTP_PAYLOADTYPE | (((rtp_data_index + rtp_payload_size)
                                                  >= length) ? RTP_MARKER_MASK : 0);

        //send RTP stream packet
        if (sendto(sock, rtp_send_packet, sizeof(rtp_hdr) + rtp_payload_size, 0, (struct sockaddr *)to, sizeof(struct sockaddr)) >= 0) {
        	//sendto : send data to socket, send 'rtp_send_packet'
        	//socket descriptor/data to send/byte length of data/option for send/destination address/size of destination address

            rtphdr->seqNum  = htons(ntohs(rtphdr->seqNum) + 1);
            //htons : Host to network short (-> to solve difference how to save data in cpu)
            //ntohl : Network to host long

            rtp_data_index += rtp_payload_size; //rtp_data_index = rtp_data_index + rtp_payload_size
        } else {
          	  printf("rtp_sender: not sendto==%i\n", errno); //errno : if error is happened, to check which error is happened
        }
    }while (rtp_data_index < length);

    free(rtp_send_packet); //free : return allocated memory to system
}

//  receives RTP packets
unsigned long rtp_recv_packets(int socket, void (*call_back)(char *, unsigned long length, char *), char *image_data){
    rtp_hdr*    rtphdr;
    struct sockaddr_in from; //represent socket address
    int fromlen;

    u_int32                received_num_bytes;
    u_int32                recvrtppackets  = 0;
    u_int32                lostrtppackets  = 0;
    u_int16            	   lastrtpseq = 0;
    u_int8 rtp_recv_packet[RTP_PACKET_SIZE];
    unsigned long       total_received_bytes = 0;

    do {
        fromlen = sizeof(from); //fromlen : from(sockaddr_in)-소켓 주소의 크기?!
        received_num_bytes  = recvfrom(socket, rtp_recv_packet, sizeof(rtp_recv_packet), 0, (struct sockaddr *)&from, (socklen_t *)&fromlen);
        //recvfrom : reseive data from socket, receive 'rtp_recv_packet'
         //socket descriptor/buffer point to receive/byte length of buffer byte/option for receive/address of send/size of address

        if (received_num_bytes >= sizeof(rtp_hdr)) {
            rtphdr = (rtp_hdr *)rtp_recv_packet;
            recvrtppackets++;

             //send packet
            if ((lastrtpseq == 0) || ((lastrtpseq + 1) == ntohs(rtphdr->seqNum))) { // || : if one of them is ture -> result is "true"
            	//ntohl : Network to host long
                total_received_bytes += received_num_bytes; //total_received_bytes = total_received_bytes + received_num_bytes
                call_back((rtp_recv_packet + sizeof(rtp_hdr)),(received_num_bytes - sizeof(rtp_hdr)), image_data);
            } else {
                lostrtppackets++;
            }

            lastrtpseq = ntohs(rtphdr->seqNum);

            //check if receive well
            if ((recvrtppackets % RTP_RECV_STATS) == 0) {
                printf("rtp_recv_thread: recv %6i packet(s) / lost %4i packet(s) (%.4f%%)...\n", recvrtppackets, lostrtppackets, (lostrtppackets*100.0)/recvrtppackets);
            }
        } else {
            printf("rtp_recv_thread: recv timeout...\n");
            return total_received_bytes;
        }
    }while(!(rtphdr->mk_pt & RTP_MARKER_MASK)); //repeat until end marker is received
    return total_received_bytes;
}

